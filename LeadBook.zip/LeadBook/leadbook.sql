-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2021 at 03:45 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.2.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `leadbook`
--

-- --------------------------------------------------------

--
-- Table structure for table `company_index`
--

CREATE TABLE `company_index` (
  `Company Name` varchar(52) NOT NULL,
  `SourceURL` varchar(130) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `company_index`
--

INSERT INTO `company_index` (`Company Name`, `SourceURL`) VALUES
('Company Name', 'SourceURL'),
('A&A Technology Group', 'https://www.adapt.io/company/a-a-technology-group'),
('A Better Answer', 'https://www.adapt.io/company/a-better-answer-4'),
('A Cheerful Giver', 'https://www.adapt.io/company/a-cheerful-giver-inc-1'),
('A-CTI', 'https://www.adapt.io/company/a-cti-1'),
('A P G Inc', 'https://www.adapt.io/company/a-p-g-inc'),
('Crexendo Business Solutions', 'https://www.adapt.io/company/a-r-management-solutions--llc'),
('A.V. Lauttamus Communications, Inc.', 'https://www.adapt.io/company/a-v--lauttamus-communications--inc-'),
('A-V Services, Inc.', 'https://www.adapt.io/company/a-v-services--inc-'),
('A1 Teletronics', 'https://www.adapt.io/company/a1-teletronics-inc-'),
('Abacus Group, Inc.', 'https://www.adapt.io/company/abacus-group--inc--1'),
('Abadi Group', 'https://www.adapt.io/company/abadi-group-1'),
('Abc Compounding', 'https://www.adapt.io/company/abc-compounding-1'),
('ABcom', 'https://www.adapt.io/company/abcom-llc'),
('Abilita', 'https://www.adapt.io/company/abilita-5'),
('ABIS', 'https://www.adapt.io/company/abis-3'),
('Abissnet', 'https://www.adapt.io/company/abissnet-sh-a'),
('Abmnus', 'https://www.adapt.io/company/abmnus-llc'),
('AboveNet', 'https://www.adapt.io/company/abovenet-2'),
('ABR Industries', 'https://www.adapt.io/company/abr-industries'),
('ABR Telecom', 'https://www.adapt.io/company/abr-telecom'),
('ABS Communications', 'https://www.adapt.io/company/abs-communications-llc'),
('acphotonics', 'https://www.adapt.io/company/ac-photonics'),
('Acacia Communications', 'https://www.adapt.io/company/acacia-communications-inc-'),
('ACBB-BITS LLC', 'https://www.adapt.io/company/acbb-bits-llc'),
('ACC Business', 'https://www.adapt.io/company/acc-business'),
('AccelTex Solutions', 'https://www.adapt.io/company/acceltex-solutions-2'),
('Acces Communications', 'https://www.adapt.io/company/accesradio-com'),
('Access Communications Cooperative Limited', 'https://www.adapt.io/company/access-communications-cooperative-limited'),
('Access Point, Inc.', 'https://www.adapt.io/company/access-point--inc--1'),
('Access Vermont', 'https://www.adapt.io/company/access-vermont'),
('Access Wireless Data Solutions', 'https://www.adapt.io/company/access-wireless-data-solutions'),
('Polycom', 'https://www.adapt.io/company/accordent-technologies'),
('accrotool.com', 'https://www.adapt.io/company/accrotool-com'),
('Accu-Tech', 'https://www.adapt.io/company/accu-tech-corporation-1'),
('AccuAir, Inc.', 'https://www.adapt.io/company/accuair--inc-'),
('AccuConference', 'https://www.adapt.io/company/accuconference'),
('Accurate Connections, Inc.', 'https://www.adapt.io/company/accurate-connections--inc-'),
('Accurate Telecom', 'https://www.adapt.io/company/accurate-telecom-1'),
('Accuris Networks', 'https://www.adapt.io/company/accuris-networks'),
('Accutel', 'https://www.adapt.io/company/accutel-com-1'),
('Accuver EMEA', 'https://www.adapt.io/company/accuver-americas-1'),
('Accuvoice Inc.', 'https://www.adapt.io/company/accuvoice-inc-'),
('ACD Direct', 'https://www.adapt.io/company/acd-direct'),
('Acecape Inc.', 'https://www.adapt.io/company/acecape-inc-'),
('ACG Systems', 'https://www.adapt.io/company/acg-systems--inc-1'),
('ACI Communications', 'https://www.adapt.io/company/aci-communications--inc-'),
('Acision', 'https://www.adapt.io/company/acision-2'),
('ACN', 'https://www.adapt.io/company/acn-29'),
('Lkn Communications Inc.', 'https://www.adapt.io/company/acn-30'),
('Acotel', 'https://www.adapt.io/company/acotel-groupo-1'),
('Argosy Communication Products Ltd.', 'https://www.adapt.io/company/acpltd-ca'),
('ACS', 'https://www.adapt.io/company/acs-86'),
('PGi', 'https://www.adapt.io/company/act-conferencing--a-pgi-company-1');

-- --------------------------------------------------------

--
-- Table structure for table `company_profiles`
--

CREATE TABLE `company_profiles` (
  `Name` varchar(52) NOT NULL,
  `Job Title` varchar(52) NOT NULL,
  `Company Name` varchar(130) NOT NULL,
  `email` varchar(52) NOT NULL,
  `emailDomain` varchar(52) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `company_profiles`
--

INSERT INTO `company_profiles` (`Name`, `Job Title`, `Company Name`, `email`, `emailDomain`) VALUES
('Name', 'Job Title', 'Company Name', 'email', 'emailDomain'),
('Phillip Neely', 'President', 'A&A Technology Group', 'p*****@aatg.net', 'aatg.net'),
('Darrin Guffy', 'Service', 'A&A Technology Group', 'd*****@aatg.net', 'aatg.net'),
('Jp Miller', 'Accounting / Operations', 'A&A Technology Group', 'j*****@aatg.net', 'aatg.net'),
('Alan Hummon', 'Vice President', 'A&A Technology Group', 'a*****@aatg.net', 'aatg.net'),
('Charles Pickering', 'Service Manager', 'A&A Technology Group', 'c*****@aatg.net', 'aatg.net'),
('Bob Krick', 'Manager, Existing Customer Base', 'A&A Technology Group', 'b*****@aatg.net', 'aatg.net'),
('Phil Anderson', 'Serveilance Systems and Telecommunications', 'A&A Technology Group', 'p*****@aatg.net', 'aatg.net'),
('William Dixson', 'Service Coordinator/Support Tech I', 'A&A Technology Group', 'w*****@aatg.net', 'aatg.net'),
('Matt Hummon', 'Systems Engineer', 'A&A Technology Group', 'm*****@aatg.net', 'aatg.net'),
('Vicki Young', 'President', 'A Better Answer', 'v*****@abetteranswer.com', 'abetteranswer.com'),
('Lola Longria', 'Information Technology Director', 'A Better Answer', 'l*****@abetteranswer.com', 'abetteranswer.com'),
('Jessica Brown', 'Director of Marketing', 'A Better Answer', 'j*****@abetteranswer.com', 'abetteranswer.com'),
('Stephanie Hyde', 'Information Technology Manager', 'A Better Answer', 's*****@abetteranswer.com', 'abetteranswer.com'),
('Hildie Ciejka', 'Customer Service Manager', 'A Better Answer', 'h*****@abetteranswer.com', 'abetteranswer.com'),
('Weiler Debbie', 'Office Manager', 'A Better Answer', 'd*****@abetteranswer.com', 'abetteranswer.com'),
('Dee Sobelman', 'Telereceptionist', 'A Better Answer', 'd*****@abetteranswer.com', 'abetteranswer.com'),
('Roseann Gibbs', 'Manager', 'A Better Answer', 'r*****@abetteranswer.com', 'abetteranswer.com'),
('Brenda Barton', 'Collection Manager', 'A Better Answer', 'b*****@abetteranswer.com', 'abetteranswer.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

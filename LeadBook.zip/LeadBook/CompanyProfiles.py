# -*- coding: utf-8 -*-
"""
Created on Fri Apr 23 04:38:35 2021

@author: A Ahad
"""

from urllib.request import urlopen as uReq
from bs4 import BeautifulSoup as BSoup
import pandas as pd
import tldextract
import json

cname=[]
curls=[] 
crev=[]
cemp=[]
cind=[]
cloc=[]
cdomain=[]
empcompany=[]
empname=[]
emptitle=[]
empemail=[]
empdomain=[]
company_profiles=[]

data = pd.read_json("company_index.json")
df_index = pd.DataFrame(data)
url_list = df_index['SourceURL'].tolist()

#myURL = 'https://www.adapt.io/company/a-better-answer-4'
try:
    for myURL in url_list:
        print(myURL)
        uClient = uReq(myURL)
        page_html = uClient.read()
        uClient.close()
        
        soup = BSoup(page_html,"html.parser")
        
        
        for c in soup.findAll('div', attrs={'class':'CompanyTopInfo_leftContentWrap__3gIch'}):
            cname.append(c.h1.text)
            comapny_name= c.h1.text
            curls.append(c.div.text)
            
            surl= c.div.text
            list = tldextract.extract(surl)
            domain_name = list.domain + '.' + list.suffix
            cdomain.append(domain_name)
        
        
        info_list = soup.find_all("span",class_="CompanyTopInfo_infoValue__27_Yo")
        for index, rev in enumerate(info_list) :
            if index == 0:
                crev.append(rev.text)
            elif index == 1:
                cemp.append(rev.text)
            elif index == 2:
                cind.append(rev.text)
            elif index == 3:
                cloc.append(rev.text)
            
        for einfo in soup.findAll('div', attrs={'class':'TopContacts_roundedBorder__1a3yB undefined'}):
            empcompany.append(comapny_name)
            empname.append(einfo.div.a.text)
            emptitle.append(einfo.p.text)
            empemail.append(einfo.button.text)
            eemail= einfo.button.text
            list = tldextract.extract(eemail)
            domain_name = list.domain + '.' + list.suffix
            empdomain.append(domain_name)
        
except:
    print("Link is Unreachable!!!, HTTP request  Failed !!!")
    
print(len(empcompany),len(empname),len(emptitle),len(empemail),len(empdomain))
df_comp = pd.DataFrame({'Company Name':cname,'SourceURL':curls,'Domain':cdomain,'Total Revenaue':crev,'TotalEmployee':cemp,'Industry':cind,'Location':cloc})
df_emp= pd.DataFrame({'Name':empname,'Job Title':emptitle,'Company Name':empcompany,'email':empemail,'emailDomain':empdomain})

df_emp.to_csv('company_profiles.csv', index=False, encoding='utf-8')

  
list_comp = df_comp.values.tolist()
list_emp = df_emp.values.tolist()
            
company_profiles= list_comp + list_emp


filename= 'company_profiles.json'
f = open(filename,'w')
jsonString = json.dumps(company_profiles)
f.write(jsonString)
f.close()



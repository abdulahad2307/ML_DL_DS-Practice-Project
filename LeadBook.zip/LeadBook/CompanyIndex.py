# -*- coding: utf-8 -*-
"""
Created on Fri Apr 23 00:37:19 2021

@author: A Ahad
"""

from urllib.request import urlopen as uReq
from bs4 import BeautifulSoup as BSoup
import pandas as pd

name=[]
urls=[] 

myURL = 'https://www.adapt.io/directory/industry/telecommunications/A-1'

uClient = uReq(myURL)
page_html = uClient.read()
uClient.close()

soup = BSoup(page_html,"html.parser")


for c in soup.findAll('div', attrs={'class':'DirectoryList_linkItemWrapper__3F2UE'}):
    name.append(c.a.text)
    urls.append(c.a['content'])

df = pd.DataFrame({'Company Name':name,'SourceURL':urls})
df.to_csv('company_index.csv', index=False, encoding='utf-8')
df_index = df.transpose()
df_index.to_json('company_index.json',orient="index")